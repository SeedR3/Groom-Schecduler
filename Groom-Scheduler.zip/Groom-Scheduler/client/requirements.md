## Packages
date-fns | Date formatting and manipulation for calendar
react-day-picker | Calendar component for date selection
recharts | Charts for the dashboard
framer-motion | Smooth animations for page transitions and dialogs
clsx | Class name utility (often needed with tailwind-merge)
tailwind-merge | Class merging utility

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["var(--font-sans)"],
  display: ["var(--font-display)"],
}
