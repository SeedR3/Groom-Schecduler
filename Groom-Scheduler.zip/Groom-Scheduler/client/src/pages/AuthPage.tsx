import { Dog } from "lucide-react";

export default function AuthPage() {
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-3xl shadow-xl p-8 border border-slate-100 text-center space-y-8 animate-enter">
        <div className="mx-auto w-20 h-20 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center text-white shadow-lg shadow-primary/25">
          <Dog size={40} />
        </div>
        
        <div>
          <h1 className="text-3xl font-bold text-slate-800 mb-2">Welcome to Pawfect</h1>
          <p className="text-slate-500">Professional Grooming Management</p>
        </div>

        <div className="space-y-4">
          <a href="/api/login" className="block w-full">
            <button className="w-full py-4 rounded-xl bg-slate-900 text-white font-bold hover:bg-slate-800 hover:-translate-y-0.5 transition-all shadow-lg hover:shadow-xl">
              Log In to Continue
            </button>
          </a>
          <p className="text-xs text-slate-400">
            Secure authentication powered by Replit
          </p>
        </div>
      </div>
    </div>
  );
}
