import { useState, useEffect } from "react";
import { format, startOfWeek, addDays, isSameDay, parseISO, addHours, startOfDay } from "date-fns";
import { PageHeader } from "@/components/PageHeader";
import { useAppointments, useCreateAppointment, useDeleteAppointment } from "@/hooks/use-appointments";
import { useClients } from "@/hooks/use-clients";
import { usePets } from "@/hooks/use-pets";
import { ChevronLeft, ChevronRight, Plus, Clock, Scissors, User, GripVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm, Controller } from "react-hook-form";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { DndContext, DragOverlay, useDraggable, useDroppable } from "@dnd-kit/core";

const SERVICES = ["Full Groom", "Bath & Brush", "Nail Trim", "Puppy Cut", "De-shedding"];
const DURATIONS = [
  { label: "30 mins", value: "30" },
  { label: "1 hour", value: "60" },
  { label: "1.5 hours", value: "90" },
  { label: "2 hours", value: "120" },
  { label: "2.5 hours", value: "150" },
  { label: "3 hours", value: "180" },
];

function DraggableClient({ client, pets }: { client: any; pets: any[] }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: `client-${client.id}`,
    data: { client, pets },
  });

  const style = transform ? {
    transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
  } : undefined;

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
      className={cn(
        "flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-100 shadow-sm cursor-grab active:cursor-grabbing hover:border-primary/50 transition-colors group mb-2",
        isDragging && "opacity-50"
      )}
    >
      <GripVertical className="h-4 w-4 text-slate-300 group-hover:text-primary transition-colors" />
      <div className="flex-1 min-w-0">
        <p className="text-sm font-bold text-slate-800 truncate">{client.name}</p>
        <p className="text-xs text-slate-500">{pets.length} {pets.length === 1 ? 'pet' : 'pets'}</p>
      </div>
    </div>
  );
}

function CalendarSlot({ day, hour, appointments, pets, clients, onSlotClick, deleteAppointment }: any) {
  const { setNodeRef, isOver } = useDroppable({
    id: `slot-${day.toISOString()}-${hour}`,
    data: { day, hour },
  });

  const isPast = new Date(day).setHours(hour) < new Date().getTime();

  return (
    <div
      ref={setNodeRef}
      className={cn(
        "border-r border-slate-100 last:border-0 p-0 relative group transition-colors min-h-[100px]",
        !isPast && "hover:bg-slate-50 cursor-pointer",
        isOver && "bg-primary/10 ring-2 ring-primary ring-inset"
      )}
      onClick={() => !isPast && onSlotClick(day, hour)}
    >
      {!isPast && appointments.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          <Plus className="h-6 w-6 text-slate-300" />
        </div>
      )}

      {appointments.map((apt: any) => {
        const pet = pets.find((p: any) => p.id === apt.petId);
        const client = clients.find((c: any) => c.id === apt.clientId);
        const durationMinutes = apt.duration || 60;
        const heightPx = (durationMinutes / 60) * 100;
        const aptDate = new Date(apt.date);
        const minutesOffset = aptDate.getMinutes();
        const topPx = (minutesOffset / 60) * 100;

        return (
          <div
            key={apt.id}
            className="absolute left-1 right-1 bg-sky-500 text-white p-3 rounded-lg text-xs hover:brightness-110 transition-all cursor-pointer shadow-md z-10 flex flex-col gap-1 overflow-hidden group"
            style={{ 
              height: `${heightPx - 4}px`,
              top: `${topPx + 2}px`
            }}
            onClick={(e) => {
              e.stopPropagation();
              if (confirm("Delete this appointment?")) {
                deleteAppointment.mutate(apt.id);
              }
            }}
          >
            <div className="flex justify-between items-start">
              <div className="font-bold text-white uppercase tracking-wider">{apt.service}</div>
              <div className="text-[10px] font-bold opacity-0 group-hover:opacity-100 transition-opacity">£{apt.price / 100}</div>
            </div>
            <div className="text-sky-100 font-medium">{pet?.name}</div>
            <div className="text-sky-200/80">{client?.name}</div>
          </div>
        );
      })}
    </div>
  );
}

export default function CalendarPage() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [sidebarSearchTerm, setSidebarSearchTerm] = useState("");
  const { data: appointments = [] } = useAppointments();
  const { data: clients = [] } = useClients();
  const { data: pets = [] } = usePets();
  const deleteAppointment = useDeleteAppointment();

  const [isBookOpen, setIsBookOpen] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState<Date | null>(null);
  const [droppedClient, setDroppedClient] = useState<any>(null);

  const filteredSidebarClients = clients.filter(client => 
    client.name.toLowerCase().includes(sidebarSearchTerm.toLowerCase()) ||
    client.email?.toLowerCase().includes(sidebarSearchTerm.toLowerCase()) ||
    client.phone?.includes(sidebarSearchTerm)
  );

  const startDate = startOfWeek(currentDate, { weekStartsOn: 1 });
  const weekDays = Array.from({ length: 7 }).map((_, i) => addDays(startDate, i));
  const timeSlots = Array.from({ length: 9 }).map((_, i) => i + 9);

  const handleSlotClick = (day: Date, hour: number) => {
    const date = new Date(day);
    date.setHours(hour, 0, 0, 0);
    setSelectedSlot(date);
    setDroppedClient(null);
    setIsBookOpen(true);
  };

  const getAppointmentsForSlot = (day: Date, hour: number) => {
    return appointments.filter(apt => {
      const aptDate = new Date(apt.date);
      // We only show the appointment in the slot it starts in
      // The absolute positioning will handle the visual overflow into next slots
      return isSameDay(aptDate, day) && aptDate.getHours() === hour;
    });
  };

  const handleDragEnd = (event: any) => {
    const { active, over } = event;
    if (over && over.id.startsWith("slot-")) {
      const clientData = active.data.current.client;
      const { day, hour } = over.data.current;
      const date = new Date(day);
      date.setHours(hour, 0, 0, 0);
      
      setSelectedSlot(date);
      setDroppedClient(clientData);
      setIsBookOpen(true);
    }
  };

  return (
    <DndContext onDragEnd={handleDragEnd}>
      <div className="flex gap-6 h-[calc(100vh-4rem)]">
        {/* Left Sidebar for Clients */}
        <div className="w-64 flex flex-col gap-4">
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col h-full overflow-hidden">
            <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
              <User size={18} className="text-primary" />
              Clients
            </h3>
            
            <div className="mb-4">
              <Input 
                placeholder="Search clients..." 
                value={sidebarSearchTerm} 
                onChange={(e) => setSidebarSearchTerm(e.target.value)}
                className="rounded-xl h-9 text-sm border-slate-200"
              />
            </div>

            <div className="flex-1 overflow-y-auto pr-2 space-y-1">
              {filteredSidebarClients.map(client => (
                <DraggableClient 
                  key={client.id} 
                  client={client} 
                  pets={pets.filter(p => p.clientId === client.id)} 
                />
              ))}
              {filteredSidebarClients.length === 0 && (
                <div className="text-center py-8 text-slate-400 text-xs">
                  No clients found
                </div>
              )}
            </div>
            <p className="text-[10px] text-slate-400 mt-4 text-center">
              Drag a client onto a slot to book
            </p>
          </div>
        </div>

        {/* Main Calendar View */}
        <div className="flex-1 space-y-6 flex flex-col">
          <div className="flex justify-between items-center">
            <PageHeader 
              title="Schedule" 
              description="Drag and drop booking management."
            />
            <div className="flex gap-2 bg-white p-1 rounded-xl border border-slate-200 shadow-sm">
              <Button variant="ghost" size="icon" onClick={() => setCurrentDate(addDays(currentDate, -7))}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <div className="px-4 py-2 font-bold text-slate-700 min-w-[140px] text-center text-sm">
                {format(startDate, "MMM d")} - {format(addDays(startDate, 6), "MMM d, yyyy")}
              </div>
              <Button variant="ghost" size="icon" onClick={() => setCurrentDate(addDays(currentDate, 7))}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="flex-1 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col animate-enter">
            <div className="grid grid-cols-8 border-b border-slate-100 bg-slate-50/50">
              <div className="p-4 border-r border-slate-100 text-xs font-bold text-slate-400 uppercase tracking-wider text-center flex items-center justify-center">
                Time
              </div>
              {weekDays.map(day => (
                <div key={day.toString()} className={cn(
                  "p-4 text-center border-r border-slate-100 last:border-0",
                  isSameDay(day, new Date()) && "bg-primary/5"
                )}>
                  <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">{format(day, "EEE")}</div>
                  <div className={cn(
                    "text-lg font-bold inline-flex w-8 h-8 items-center justify-center rounded-full",
                    isSameDay(day, new Date()) ? "bg-primary text-white shadow-lg shadow-primary/30" : "text-slate-700"
                  )}>
                    {format(day, "d")}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex-1 overflow-y-auto">
              {timeSlots.map(hour => (
                <div key={hour} className="grid grid-cols-8 border-b border-slate-50 min-h-[100px]">
                  <div className="border-r border-slate-100 p-3 text-xs font-semibold text-slate-400 text-center sticky left-0 bg-white z-10">
                    {hour}:00
                  </div>
                  {weekDays.map(day => (
                    <CalendarSlot
                      key={day.toString()}
                      day={day}
                      hour={hour}
                      appointments={getAppointmentsForSlot(day, hour)}
                      pets={pets}
                      clients={clients}
                      onSlotClick={handleSlotClick}
                      deleteAppointment={deleteAppointment}
                    />
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <BookingDialog 
        open={isBookOpen} 
        onOpenChange={setIsBookOpen} 
        initialDate={selectedSlot}
        droppedClient={droppedClient}
        clients={clients}
        pets={pets}
      />
    </DndContext>
  );
}

function BookingDialog({ open, onOpenChange, initialDate, droppedClient, clients, pets }: any) {
  const createAppointment = useCreateAppointment();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  
  const form = useForm({
    values: {
      clientId: droppedClient?.id?.toString() || "",
      petId: "",
      service: "",
      duration: "60",
      price: "50",
      notes: ""
    }
  });

  const selectedClientId = form.watch("clientId");
  const filteredClients = clients.filter((c: any) => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.phone?.includes(searchTerm)
  );
  
  const availablePets = pets.filter((p: any) => p.clientId === Number(selectedClientId));

  useEffect(() => {
    if (!open) {
      setSearchTerm("");
    }
  }, [open]);

  const onSubmit = async (data: any) => {
    try {
      if (!initialDate) return;

      await createAppointment.mutateAsync({
        clientId: Number(data.clientId),
        petId: Number(data.petId),
        date: initialDate.toISOString(),
        service: data.service,
        duration: Number(data.duration),
        price: Number(data.price) * 100,
        notes: data.notes,
        status: "scheduled"
      });

      toast({ title: "Appointment Booked!", description: "See you then!" });
      onOpenChange(false);
      form.reset();
    } catch (err) {
      toast({ title: "Error", description: "Could not book appointment.", variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px] rounded-3xl p-6">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-slate-800">New Appointment</DialogTitle>
          <p className="text-slate-500 flex items-center gap-2">
            <Clock className="w-4 h-4" />
            {initialDate && format(initialDate, "MMMM do, h:mm a")}
          </p>
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label>Client</Label>
            <div className="flex flex-col gap-2">
              <Input 
                placeholder="Search clients..." 
                value={searchTerm} 
                onChange={(e) => setSearchTerm(e.target.value)}
                className="rounded-xl h-8 text-xs"
              />
              <Controller
                control={form.control}
                name="clientId"
                rules={{ required: true }}
                render={({ field }) => (
                  <Select onValueChange={field.onChange} value={field.value}>
                    <SelectTrigger className="rounded-xl">
                      <SelectValue placeholder="Select Client" />
                    </SelectTrigger>
                    <SelectContent>
                      {filteredClients.length > 0 ? (
                        filteredClients.map((c: any) => (
                          <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>
                        ))
                      ) : (
                        <div className="p-2 text-xs text-slate-500 text-center">No clients found</div>
                      )}
                    </SelectContent>
                  </Select>
                )}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Pet</Label>
            <Controller
              control={form.control}
              name="petId"
              rules={{ required: true }}
              render={({ field }) => (
                <Select onValueChange={field.onChange} value={field.value} disabled={!selectedClientId}>
                  <SelectTrigger className="rounded-xl">
                    <SelectValue placeholder="Select Pet" />
                  </SelectTrigger>
                  <SelectContent>
                    {availablePets.map((p: any) => (
                      <SelectItem key={p.id} value={p.id.toString()}>
                        {p.name} ({p.breed})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            />
          </div>

          <div className="space-y-2">
            <Label>Service</Label>
            <Controller
              control={form.control}
              name="service"
              rules={{ required: true }}
              render={({ field }) => (
                <Select onValueChange={field.onChange} value={field.value}>
                  <SelectTrigger className="rounded-xl">
                    <SelectValue placeholder="Select Service" />
                  </SelectTrigger>
                  <SelectContent>
                    {SERVICES.map(s => (
                      <SelectItem key={s} value={s}>{s}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            />
          </div>

          <div className="space-y-2">
            <Label>Duration</Label>
            <Controller
              control={form.control}
              name="duration"
              rules={{ required: true }}
              render={({ field }) => (
                <Select onValueChange={field.onChange} value={field.value}>
                  <SelectTrigger className="rounded-xl">
                    <SelectValue placeholder="Select Duration" />
                  </SelectTrigger>
                  <SelectContent>
                    {DURATIONS.map(d => (
                      <SelectItem key={d.value} value={d.value}>{d.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            />
          </div>

          <div className="space-y-2">
            <Label>Price (£)</Label>
            <Input type="number" {...form.register("price")} className="rounded-xl" />
          </div>

          <div className="flex flex-col gap-3 pt-4">
            <Button type="submit" disabled={createAppointment.isPending} className="bg-primary hover:bg-primary/90 rounded-xl w-full">
              {createAppointment.isPending ? <Loader2 className="animate-spin" /> : "Book Appointment"}
            </Button>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="rounded-xl w-full">Cancel</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
