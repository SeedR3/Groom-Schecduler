import { useState } from "react";
import { PageHeader } from "@/components/PageHeader";
import { useClients, useCreateClient, useDeleteClient, useUpdateClient } from "@/hooks/use-clients";
import { usePets, useCreatePet } from "@/hooks/use-pets";
import { Plus, Search, MoreHorizontal, Phone, Mail, MapPin, Trash, Edit } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertClientSchema, type InsertClient } from "@shared/schema";
import { z } from "zod";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

export default function Clients() {
  const { data: clients, isLoading } = useClients();
  const { data: pets } = usePets();
  const [search, setSearch] = useState("");
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  const filteredClients = clients?.filter(client => 
    client.name.toLowerCase().includes(search.toLowerCase()) ||
    client.email?.toLowerCase().includes(search.toLowerCase()) ||
    client.phone?.includes(search)
  );

  return (
    <div className="space-y-8 pb-10">
      <PageHeader
        title="Clients"
        description="Manage your furry friends and their owners."
        action={
          <Button 
            onClick={() => setIsCreateOpen(true)}
            className="bg-primary hover:bg-primary/90 text-white rounded-xl px-6 font-semibold shadow-lg shadow-primary/25 hover:shadow-xl hover:-translate-y-0.5 transition-all"
          >
            <Plus className="mr-2 h-4 w-4" /> Add Client
          </Button>
        }
      />

      {/* Search Bar */}
      <div className="relative max-w-md animate-enter">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 h-4 w-4" />
        <Input
          placeholder="Search clients..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10 h-12 rounded-xl border-slate-200 focus:border-primary focus:ring-primary/20 bg-white shadow-sm"
        />
      </div>

      <ClientDialog open={isCreateOpen} onOpenChange={setIsCreateOpen} />

      {isLoading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 animate-enter" style={{ animationDelay: '0.1s' }}>
          {filteredClients?.map((client) => {
            const clientPets = pets?.filter(p => p.clientId === client.id) || [];
            
            return (
              <ClientCard key={client.id} client={client} pets={clientPets} />
            );
          })}
          {filteredClients?.length === 0 && (
            <div className="col-span-full text-center py-16 bg-white rounded-3xl border border-dashed border-slate-200">
              <p className="text-slate-400">No clients found matching your search.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ClientCard({ client, pets }: { client: any, pets: any[] }) {
  const [isEditOpen, setIsEditOpen] = useState(false);
  const deleteClient = useDeleteClient();
  const { toast } = useToast();

  const handleDelete = async () => {
    if (confirm("Are you sure? This will delete the client and all their pets.")) {
      await deleteClient.mutateAsync(client.id);
      toast({ title: "Client deleted", description: "The client record has been removed." });
    }
  };

  return (
    <>
      <div className="group bg-white rounded-2xl p-6 border border-slate-100 shadow-sm hover:shadow-md hover:border-primary/20 transition-all duration-300 relative">
        <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                <MoreHorizontal className="h-4 w-4 text-slate-400" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40 rounded-xl">
              <DropdownMenuItem onClick={() => setIsEditOpen(true)} className="cursor-pointer">
                <Edit className="mr-2 h-4 w-4" /> Edit
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleDelete} className="text-destructive cursor-pointer focus:text-destructive">
                <Trash className="mr-2 h-4 w-4" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <div className="flex items-center gap-4 mb-4">
          <div className="h-12 w-12 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold text-lg shadow-md">
            {client.name.charAt(0).toUpperCase()}
          </div>
          <div>
            <h3 className="font-bold text-slate-800 text-lg">{client.name}</h3>
            <p className="text-xs text-slate-400">Client ID: #{client.id}</p>
          </div>
        </div>

        <div className="space-y-2 mb-6">
          {client.phone && (
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <Phone className="h-3.5 w-3.5" /> {client.phone}
            </div>
          )}
          {client.email && (
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <Mail className="h-3.5 w-3.5" /> {client.email}
            </div>
          )}
          {client.address && (
            <div className="flex items-center gap-2 text-sm text-slate-500">
              <MapPin className="h-3.5 w-3.5" /> {client.address}
            </div>
          )}
        </div>

        <div className="border-t border-slate-50 pt-4">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Pets</p>
          <div className="flex flex-wrap gap-2">
            {pets.length > 0 ? (
              pets.map(pet => (
                <span key={pet.id} className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-accent/10 text-accent-foreground">
                  {pet.name}
                </span>
              ))
            ) : (
              <span className="text-xs text-slate-400 italic">No pets registered</span>
            )}
          </div>
        </div>
      </div>

      <ClientDialog 
        open={isEditOpen} 
        onOpenChange={setIsEditOpen} 
        client={client} 
      />
    </>
  );
}

function ClientDialog({ open, onOpenChange, client }: { open: boolean, onOpenChange: (open: boolean) => void, client?: any }) {
  const createClient = useCreateClient();
  const updateClient = useUpdateClient();
  const createPet = useCreatePet();
  const { toast } = useToast();
  const [addPet, setAddPet] = useState(false);

  const form = useForm<InsertClient & { petName?: string, petBreed?: string, petAge?: string }>({
    resolver: zodResolver(insertClientSchema.extend({
      petName: z.string().optional(),
      petBreed: z.string().optional(),
      petAge: z.string().optional(),
    })),
    defaultValues: client || {
      name: "",
      email: "",
      phone: "",
      address: "",
      notes: "",
      petName: "",
      petBreed: "",
      petAge: ""
    }
  });

  const onSubmit = async (data: any) => {
    try {
      if (client) {
        await updateClient.mutateAsync({ id: client.id, ...data });
        toast({ title: "Success", description: "Client updated successfully." });
      } else {
        const newClient = await createClient.mutateAsync(data);
        if (addPet && data.petName) {
          await createPet.mutateAsync({
            name: data.petName,
            breed: data.petBreed,
            age: data.petAge ? Number(data.petAge) : undefined,
            clientId: newClient.id,
            notes: "",
            groomingNotes: ""
          });
        }
        toast({ title: "Success", description: "Client created successfully." });
      }
      onOpenChange(false);
      form.reset();
      setAddPet(false);
    } catch (error) {
      toast({ 
        title: "Error", 
        description: "Failed to save client. Please check your input.",
        variant: "destructive"
      });
    }
  };

  const isPending = createClient.isPending || updateClient.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] rounded-3xl p-6">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-slate-800">
            {client ? "Edit Client" : "Add New Client"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name</Label>
            <Input id="name" {...form.register("name")} className="rounded-xl" />
            {form.formState.errors.name && <p className="text-red-500 text-xs">{form.formState.errors.name.message}</p>}
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" {...form.register("email")} className="rounded-xl" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input id="phone" {...form.register("phone")} className="rounded-xl" />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="address">Address</Label>
            <Input id="address" {...form.register("address")} className="rounded-xl" />
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes</Label>
            <Textarea id="notes" {...form.register("notes")} className="rounded-xl" placeholder="Gate code, preferences, etc." />
          </div>

          {!client && (
            <div className="space-y-4 pt-4 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <Label className="text-slate-800 font-bold">Add a pet now?</Label>
                <input 
                  type="checkbox" 
                  checked={addPet} 
                  onChange={(e) => setAddPet(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-primary focus:ring-primary"
                />
              </div>
              
              {addPet && (
                <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-200">
                  <div className="space-y-2">
                    <Label htmlFor="petName">Pet Name</Label>
                    <Input id="petName" {...form.register("petName")} className="rounded-xl" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="petBreed">Breed</Label>
                      <Input id="petBreed" {...form.register("petBreed")} className="rounded-xl" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="petAge">Age</Label>
                      <Input id="petAge" type="number" {...form.register("petAge")} className="rounded-xl" />
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="rounded-xl">Cancel</Button>
            <Button type="submit" disabled={isPending} className="bg-primary hover:bg-primary/90 rounded-xl px-8">
              {isPending ? <Loader2 className="animate-spin" /> : (client ? "Save Changes" : "Create Client")}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
