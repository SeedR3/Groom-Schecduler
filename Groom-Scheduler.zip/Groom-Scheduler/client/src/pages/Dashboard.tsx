import { Link } from "wouter";
import { useMemo } from "react";
import { format } from "date-fns";
import { Scissors, Users, CalendarDays, DollarSign, Clock } from "lucide-react";
import { PageHeader } from "@/components/PageHeader";
import { StatCard } from "@/components/StatCard";
import { useAppointments } from "@/hooks/use-appointments";
import { useClients } from "@/hooks/use-clients";
import { usePets } from "@/hooks/use-pets";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell
} from "recharts";

export default function Dashboard() {
  const { data: appointments = [] } = useAppointments();
  const { data: clients = [] } = useClients();
  const { data: pets = [] } = usePets();

  const stats = useMemo(() => {
    const today = new Date().toDateString();
    const todaysAppointments = appointments.filter(
      (a) => new Date(a.date).toDateString() === today
    );

    const pendingRevenue = appointments
      .filter((a) => a.status === "scheduled" || a.status === "completed")
      .reduce((sum, a) => sum + (a.price || 0), 0);
    
    // Group appointments by status for chart
    const statusCounts = appointments.reduce((acc, curr) => {
      const status = curr.status || "scheduled";
      acc[status] = (acc[status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const chartData = [
      { name: "Scheduled", value: statusCounts.scheduled || 0, color: "#0d9488" }, // teal-600
      { name: "Completed", value: statusCounts.completed || 0, color: "#10b981" }, // emerald-500
      { name: "Cancelled", value: statusCounts.cancelled || 0, color: "#ef4444" }, // red-500
    ];

    return {
      todayCount: todaysAppointments.length,
      totalClients: clients.length,
      totalPets: pets.length,
      revenue: pendingRevenue / 100, // cents to pounds
      chartData
    };
  }, [appointments, clients, pets]);

  const upcomingAppointments = appointments
    .filter(a => new Date(a.date) > new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-8 pb-10">
      <PageHeader 
        title="Dashboard" 
        description={`Welcome back! Here's what's happening today, ${format(new Date(), "EEEE, MMMM do")}.`}
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 animate-enter" style={{ animationDelay: "0.1s" }}>
        <StatCard
          title="Appointments Today"
          value={stats.todayCount}
          icon={CalendarDays}
          color="primary"
        />
        <StatCard
          title="Active Clients"
          value={stats.totalClients}
          icon={Users}
          color="blue"
        />
        <StatCard
          title="Total Pets"
          value={stats.totalPets}
          icon={Scissors}
          color="accent"
        />
        <StatCard
          title="Projected Revenue"
          value={`£${stats.revenue.toLocaleString()}`}
          icon={DollarSign}
          color="green"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
        {/* Chart Section */}
        <div className="lg:col-span-2 bg-white rounded-3xl p-6 border border-slate-100 shadow-sm animate-enter" style={{ animationDelay: "0.2s" }}>
          <h3 className="text-lg font-bold text-slate-800 mb-6">Appointment Overview</h3>
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#64748b', fontSize: 12 }} 
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#64748b', fontSize: 12 }} 
                />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="value" radius={[6, 6, 0, 0]} barSize={50}>
                  {stats.chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Upcoming List */}
        <div className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm animate-enter" style={{ animationDelay: "0.3s" }}>
          <h3 className="text-lg font-bold text-slate-800 mb-6">Upcoming</h3>
          <div className="space-y-4">
            {upcomingAppointments.length === 0 ? (
              <p className="text-slate-400 text-sm text-center py-8">No upcoming appointments.</p>
            ) : (
              upcomingAppointments.map((apt) => {
                const pet = pets.find(p => p.id === apt.petId);
                const client = clients.find(c => c.id === apt.clientId);
                return (
                  <div key={apt.id} className="flex items-start gap-4 p-3 hover:bg-slate-50 rounded-xl transition-colors">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm shrink-0">
                      {format(new Date(apt.date), "dd")}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <h4 className="text-sm font-bold text-slate-800 truncate">{pet?.name || 'Unknown Pet'}</h4>
                        <span className="text-xs font-medium text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">
                          {format(new Date(apt.date), "HH:mm")}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 truncate">{client?.name}</p>
                      <div className="flex items-center gap-1 mt-1 text-xs text-primary font-medium">
                        <Scissors size={12} />
                        {apt.service}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
          
          <Link href="/calendar" className="mt-6 block text-center text-sm font-bold text-primary hover:text-primary/80 transition-colors">
            View Calendar →
          </Link>
        </div>
      </div>
    </div>
  );
}
