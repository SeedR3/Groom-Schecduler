import { useState } from "react";
import { format } from "date-fns";
import { PageHeader } from "@/components/PageHeader";
import { usePets, useCreatePet, useUpdatePet, useDeletePet } from "@/hooks/use-pets";
import { useAppointments } from "@/hooks/use-appointments";
import { useClients } from "@/hooks/use-clients";
import { Plus, Search, Trash, Edit, Dog, AlertCircle, Clock, Scissors } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertPetSchema, type InsertPet } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

export default function Pets() {
  const { data: pets, isLoading } = usePets();
  const { data: clients } = useClients();
  const [search, setSearch] = useState("");
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  const filteredPets = pets?.filter(pet => 
    pet.name.toLowerCase().includes(search.toLowerCase()) ||
    pet.breed?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8 pb-10">
      <PageHeader
        title="Pet Records"
        description="Manage furry profiles, breeds, and medical notes."
        action={
          <Button 
            onClick={() => setIsCreateOpen(true)}
            className="bg-primary hover:bg-primary/90 text-white rounded-xl px-6 font-semibold shadow-lg shadow-primary/25 hover:shadow-xl hover:-translate-y-0.5 transition-all"
          >
            <Plus className="mr-2 h-4 w-4" /> Add Pet
          </Button>
        }
      />

      <div className="relative max-w-md animate-enter">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 h-4 w-4" />
        <Input
          placeholder="Search pets by name or breed..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10 h-12 rounded-xl border-slate-200 focus:border-primary focus:ring-primary/20 bg-white shadow-sm"
        />
      </div>

      <PetDialog open={isCreateOpen} onOpenChange={setIsCreateOpen} clients={clients || []} />

      {isLoading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 animate-enter" style={{ animationDelay: '0.1s' }}>
          {filteredPets?.map((pet) => {
            const owner = clients?.find(c => c.id === pet.clientId);
            return <PetCard key={pet.id} pet={pet} ownerName={owner?.name} clients={clients || []} />;
          })}
          {filteredPets?.length === 0 && (
             <div className="col-span-full text-center py-16 bg-white rounded-3xl border border-dashed border-slate-200">
               <p className="text-slate-400">No pets found.</p>
             </div>
          )}
        </div>
      )}
    </div>
  );
}

function PetCard({ pet, ownerName, clients }: { pet: any, ownerName?: string, clients: any[] }) {
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const deletePet = useDeletePet();
  const { data: appointments } = useAppointments();
  const { toast } = useToast();

  const groomingHistory = appointments?.filter(a => a.petId === pet.id && a.status === "completed")
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()) || [];

  const handleDelete = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm(`Are you sure you want to remove ${pet.name}?`)) {
      await deletePet.mutateAsync(pet.id);
      toast({ title: "Pet removed", description: "The pet record has been deleted." });
    }
  };

  return (
    <>
      <div 
        onClick={() => setIsEditOpen(true)}
        className="group bg-white rounded-2xl p-5 border border-slate-100 shadow-sm hover:shadow-lg hover:border-primary/30 transition-all duration-300 cursor-pointer relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-accent to-accent/50" />
        
        <div className="flex justify-between items-start mb-4">
          <div className="h-14 w-14 rounded-2xl bg-slate-50 flex items-center justify-center text-slate-300 group-hover:bg-primary/5 group-hover:text-primary transition-colors">
            <Dog size={32} strokeWidth={1.5} />
          </div>
          <div className="flex gap-1 -mt-2 -mr-2">
            <Button
              variant="ghost"
              size="icon"
              className="text-slate-300 hover:text-primary hover:bg-primary/10"
              onClick={(e) => {
                e.stopPropagation();
                setIsHistoryOpen(true);
              }}
            >
              <Clock size={16} />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="text-slate-300 hover:text-destructive hover:bg-destructive/10"
              onClick={handleDelete}
            >
              <Trash size={16} />
            </Button>
          </div>
        </div>

        <div>
          <h3 className="font-bold text-slate-800 text-lg">{pet.name}</h3>
          <p className="text-sm text-slate-500 font-medium">{pet.breed || "Unknown Breed"}</p>
        </div>

        <div className="mt-4 pt-4 border-t border-slate-50 flex flex-col gap-2">
          <div className="flex justify-between text-xs">
            <span className="text-slate-400">Age</span>
            <span className="font-semibold text-slate-600">{pet.age ? `${pet.age} years` : "-"}</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-slate-400">Owner</span>
            <span className="font-semibold text-primary">{ownerName || "Unknown"}</span>
          </div>
        </div>
        
        {pet.notes && (
          <div className="mt-3 bg-yellow-50 p-2 rounded-lg flex gap-2 items-start">
            <AlertCircle className="w-3 h-3 text-yellow-600 mt-0.5 shrink-0" />
            <p className="text-[10px] text-yellow-700 line-clamp-2">{pet.notes}</p>
          </div>
        )}

        {pet.groomingNotes && (
          <div className="mt-2 bg-sky-50 p-2 rounded-lg flex gap-2 items-start">
            <Scissors className="w-3 h-3 text-sky-600 mt-0.5 shrink-0" />
            <p className="text-[10px] text-sky-700 line-clamp-2">{pet.groomingNotes}</p>
          </div>
        )}
      </div>

      <PetDialog open={isEditOpen} onOpenChange={setIsEditOpen} pet={pet} clients={clients} />

      <Dialog open={isHistoryOpen} onOpenChange={setIsHistoryOpen}>
        <DialogContent className="sm:max-w-[425px] rounded-3xl p-6">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-slate-800 flex items-center gap-2">
              <Clock className="text-primary" />
              Grooming History
            </DialogTitle>
            <p className="text-slate-500">Completed visits for {pet.name}</p>
          </DialogHeader>
          <div className="mt-4 space-y-4 max-h-[400px] overflow-y-auto pr-2">
            {groomingHistory.length > 0 ? (
              groomingHistory.map((apt) => (
                <div key={apt.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-bold text-slate-800">{format(new Date(apt.date), "MMM d, yyyy")}</span>
                    <span className="text-primary font-bold">£{apt.price / 100}</span>
                  </div>
                  <div className="text-sm text-slate-600 font-medium mb-1">{apt.service}</div>
                  {apt.notes && (
                    <div className="text-xs text-slate-400 italic mt-2 border-t border-slate-200 pt-2">
                      "{apt.notes}"
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-slate-400 text-sm">
                No completed grooming history found.
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

function PetDialog({ open, onOpenChange, pet, clients }: { open: boolean, onOpenChange: (open: boolean) => void, pet?: any, clients: any[] }) {
  const createPet = useCreatePet();
  const updatePet = useUpdatePet();
  const { toast } = useToast();

  const form = useForm<InsertPet>({
    resolver: zodResolver(insertPetSchema),
    defaultValues: pet ? {
      ...pet,
      clientId: pet.clientId.toString() // Needed for select value handling sometimes
    } : {
      name: "",
      breed: "",
      age: undefined,
      notes: "",
      groomingNotes: "",
      clientId: undefined
    }
  });

  const onSubmit = async (data: InsertPet) => {
    try {
      // Ensure age is number or undefined (empty string from input)
      const payload = {
         ...data,
         age: data.age ? Number(data.age) : undefined,
         clientId: Number(data.clientId)
      };

      if (pet) {
        await updatePet.mutateAsync({ id: pet.id, ...payload });
        toast({ title: "Success", description: "Pet updated successfully." });
      } else {
        await createPet.mutateAsync(payload);
        toast({ title: "Success", description: "Pet created successfully." });
      }
      onOpenChange(false);
      form.reset();
    } catch (error) {
      toast({ 
        title: "Error", 
        description: "Failed to save pet. Ensure an owner is selected.",
        variant: "destructive"
      });
    }
  };

  const isPending = createPet.isPending || updatePet.isPending;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] rounded-3xl p-6">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-slate-800">
            {pet ? "Edit Pet" : "Add New Pet"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="clientId">Owner</Label>
            <Controller
              control={form.control}
              name="clientId"
              render={({ field }) => (
                <Select onValueChange={(val) => field.onChange(Number(val))} value={field.value?.toString()}>
                  <SelectTrigger className="rounded-xl w-full">
                    <SelectValue placeholder="Select Owner" />
                  </SelectTrigger>
                  <SelectContent>
                    {clients.map(c => (
                      <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            />
            {form.formState.errors.clientId && <p className="text-red-500 text-xs">Owner is required</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="name">Pet Name</Label>
            <Input id="name" {...form.register("name")} className="rounded-xl" />
            {form.formState.errors.name && <p className="text-red-500 text-xs">{form.formState.errors.name.message}</p>}
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="breed">Breed</Label>
              <Input id="breed" {...form.register("breed")} className="rounded-xl" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="age">Age</Label>
              <Input id="age" type="number" {...form.register("age", { valueAsNumber: true })} className="rounded-xl" />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Medical / Behavior Notes</Label>
            <Textarea id="notes" {...form.register("notes")} className="rounded-xl" placeholder="Allergies, aggression, etc." />
          </div>

          <div className="space-y-2">
            <Label htmlFor="groomingNotes">Grooming Notes</Label>
            <Textarea id="groomingNotes" {...form.register("groomingNotes")} className="rounded-xl" placeholder="Style preferences, blade sizes, etc." />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="rounded-xl">Cancel</Button>
            <Button type="submit" disabled={isPending} className="bg-primary hover:bg-primary/90 rounded-xl px-8">
              {isPending ? <Loader2 className="animate-spin" /> : (pet ? "Save Changes" : "Add Pet")}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
