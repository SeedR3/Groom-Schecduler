# Pawfect Grooming Studio

## Overview

Pawfect is a pet grooming business management application built with a React frontend and Express backend. It provides scheduling, client management, pet records, and dashboard analytics for grooming professionals. The application uses Replit Auth for authentication and PostgreSQL for data persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state caching and synchronization
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom theming (teal/cyan palette with playful fonts)
- **Forms**: React Hook Form with Zod validation via @hookform/resolvers
- **Charts**: Recharts for dashboard visualizations

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Session Management**: express-session with connect-pg-simple for PostgreSQL session storage
- **Authentication**: Replit Auth via OpenID Connect (OIDC)
- **API Pattern**: RESTful endpoints defined in shared/routes.ts with Zod schemas for validation

### Data Layer
- **Database**: PostgreSQL (configured via DATABASE_URL environment variable)
- **Schema Location**: shared/schema.ts defines all tables (users, sessions, clients, pets, appointments)
- **Migrations**: Drizzle Kit with migrations output to ./migrations directory
- **Type Safety**: drizzle-zod generates Zod schemas from database tables

### Build System
- **Development**: Vite dev server with HMR, proxied through Express
- **Production**: Vite builds frontend to dist/public, esbuild bundles server to dist/index.cjs
- **Build Script**: Custom script at script/build.ts handles both client and server builds

### Project Structure
```
client/           # React frontend application
  src/
    components/   # Reusable UI components
    pages/        # Route page components
    hooks/        # Custom React hooks (auth, data fetching)
    lib/          # Utilities and query client setup
server/           # Express backend
  replit_integrations/auth/  # Replit Auth integration
shared/           # Shared code between client and server
  schema.ts       # Database schema definitions
  routes.ts       # API route definitions with Zod schemas
  models/         # Shared TypeScript models
```

### Authentication Flow
The application uses Replit Auth which handles user authentication through OpenID Connect. Users table stores profile information, and sessions table manages active sessions. Protected routes check authentication status via the useAuth hook.

## External Dependencies

### Database
- **PostgreSQL**: Primary data store, connection via DATABASE_URL environment variable
- **Session Storage**: Sessions stored in PostgreSQL using connect-pg-simple

### Authentication
- **Replit Auth**: OIDC-based authentication requiring ISSUER_URL, REPL_ID, and SESSION_SECRET environment variables

### Required Environment Variables
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: Secret for session encryption
- `REPL_ID`: Replit project identifier (auto-set in Replit environment)
- `ISSUER_URL`: OIDC issuer URL (defaults to https://replit.com/oidc)

### Key npm Dependencies
- drizzle-orm, drizzle-kit: Database ORM and migrations
- @tanstack/react-query: Data fetching and caching
- express, express-session: Server framework and sessions
- zod: Runtime validation
- date-fns: Date manipulation
- recharts: Dashboard charts
- react-day-picker: Calendar component