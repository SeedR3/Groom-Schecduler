import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup authentication first
  await setupAuth(app);
  registerAuthRoutes(app);

  // Clients
  app.get(api.clients.list.path, async (req, res) => {
    const clients = await storage.getClients();
    res.json(clients);
  });

  app.get(api.clients.get.path, async (req, res) => {
    const client = await storage.getClient(Number(req.params.id));
    if (!client) return res.status(404).json({ message: "Client not found" });
    res.json(client);
  });

  app.post(api.clients.create.path, async (req, res) => {
    try {
      const input = api.clients.create.input.parse(req.body);
      const client = await storage.createClient(input);
      res.status(201).json(client);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.put(api.clients.update.path, async (req, res) => {
    try {
      const input = api.clients.update.input.parse(req.body);
      const client = await storage.updateClient(Number(req.params.id), input);
      res.json(client);
    } catch (err) {
        if (err instanceof z.ZodError) {
            return res.status(400).json({ message: err.errors[0].message });
        }
        res.status(404).json({ message: "Client not found" });
    }
  });

  app.delete(api.clients.delete.path, async (req, res) => {
    await storage.deleteClient(Number(req.params.id));
    res.status(204).end();
  });

  // Pets
  app.get(api.pets.list.path, async (req, res) => {
    const pets = await storage.getPets();
    res.json(pets);
  });

  app.post(api.pets.create.path, async (req, res) => {
    try {
      const input = api.pets.create.input.parse(req.body);
      const pet = await storage.createPet(input);
      res.status(201).json(pet);
    } catch (err) {
        if (err instanceof z.ZodError) {
            return res.status(400).json({ message: err.errors[0].message });
        }
        throw err;
    }
  });

  app.put(api.pets.update.path, async (req, res) => {
     try {
      const input = api.pets.update.input.parse(req.body);
      const pet = await storage.updatePet(Number(req.params.id), input);
      res.json(pet);
    } catch (err) {
        if (err instanceof z.ZodError) {
            return res.status(400).json({ message: err.errors[0].message });
        }
        res.status(404).json({ message: "Pet not found" });
    }
  });

  app.delete(api.pets.delete.path, async (req, res) => {
      await storage.deletePet(Number(req.params.id));
      res.status(204).end();
  });

  // Appointments
  app.get(api.appointments.list.path, async (req, res) => {
    const appointments = await storage.getAppointments();
    res.json(appointments);
  });

  app.post(api.appointments.create.path, async (req, res) => {
    try {
      const body = {
        ...req.body,
        date: new Date(req.body.date)
      };
      const input = api.appointments.create.input.parse(body);
      const appointment = await storage.createAppointment(input);
      res.status(201).json(appointment);
    } catch (err) {
       if (err instanceof z.ZodError) {
            return res.status(400).json({ message: err.errors[0].message });
        }
        throw err;
    }
  });

   app.put(api.appointments.update.path, async (req, res) => {
    try {
      const body = {
        ...req.body,
        date: req.body.date ? new Date(req.body.date) : undefined
      };
      const input = api.appointments.update.input.parse(body);
      const appointment = await storage.updateAppointment(Number(req.params.id), input);
      res.json(appointment);
    } catch (err) {
       if (err instanceof z.ZodError) {
            return res.status(400).json({ message: err.errors[0].message });
        }
        res.status(404).json({ message: "Appointment not found" });
    }
  });

  app.delete(api.appointments.delete.path, async (req, res) => {
    await storage.deleteAppointment(Number(req.params.id));
    res.status(204).end();
  });

  // Seed Data
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
    const existingClients = await storage.getClients();
    if (existingClients.length === 0) {
        const client = await storage.createClient({
            name: "Alice Johnson",
            email: "alice@example.com",
            phone: "555-0123",
            address: "123 Maple St",
            notes: "Prefers morning appointments"
        });
        const pet = await storage.createPet({
            clientId: client.id,
            name: "Buddy",
            breed: "Golden Retriever",
            age: 3,
            notes: "Very friendly, loves treats"
        });
        await storage.createAppointment({
            clientId: client.id,
            petId: pet.id,
            date: new Date(Date.now() + 86400000), // Tomorrow
            service: "Full Groom",
            status: "scheduled",
            price: 5000,
            notes: "Include nail trim"
        });
        
         const client2 = await storage.createClient({
            name: "Bob Smith",
            email: "bob@example.com",
            phone: "555-0456",
            address: "456 Oak St",
            notes: ""
        });
        const pet2 = await storage.createPet({
            clientId: client2.id,
            name: "Luna",
            breed: "Poodle",
            age: 2,
            notes: "Anxious around dryers"
        });
    }
}
