import { pgTable, text, serial, integer, boolean, timestamp, jsonb, varchar, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations, sql } from "drizzle-orm";

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  username: text("username"), // Keep for compatibility if needed
  password: text("password"), // Keep for compatibility if needed
});

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)]
);

export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  address: text("address"),
  notes: text("notes"),
});

export const pets = pgTable("pets", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").references(() => clients.id).notNull(),
  name: text("name").notNull(),
  breed: text("breed"),
  age: integer("age"),
  notes: text("notes"),
  groomingNotes: text("grooming_notes"),
});

export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").references(() => clients.id).notNull(),
  petId: integer("pet_id").references(() => pets.id).notNull(),
  date: timestamp("date").notNull(),
  service: text("service").notNull(), // e.g., "Full Groom", "Bath & Brush"
  status: text("status").default("scheduled"), // scheduled, completed, cancelled
  notes: text("notes"),
  price: integer("price"), // in cents
  duration: integer("duration").default(60), // in minutes
});

export const clientsRelations = relations(clients, ({ many }) => ({
  pets: many(pets),
  appointments: many(appointments),
}));

export const petsRelations = relations(pets, ({ one, many }) => ({
  client: one(clients, {
    fields: [pets.clientId],
    references: [clients.id],
  }),
  appointments: many(appointments),
}));

export const appointmentsRelations = relations(appointments, ({ one }) => ({
  client: one(clients, {
    fields: [appointments.clientId],
    references: [clients.id],
  }),
  pet: one(pets, {
    fields: [appointments.petId],
    references: [pets.id],
  }),
}));

export const insertUserSchema = createInsertSchema(users);
export const insertClientSchema = createInsertSchema(clients).omit({ id: true });
export const insertPetSchema = createInsertSchema(pets).omit({ id: true });
export const insertAppointmentSchema = createInsertSchema(appointments).omit({ id: true });

export type User = typeof users.$inferSelect;
export type Client = typeof clients.$inferSelect;
export type Pet = typeof pets.$inferSelect;
export type Appointment = typeof appointments.$inferSelect;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertClient = z.infer<typeof insertClientSchema>;
export type InsertPet = z.infer<typeof insertPetSchema>;
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
